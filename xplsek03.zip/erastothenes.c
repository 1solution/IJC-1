// steg-decode.c
// �e�en� IJC-DU1, p��klad 1/2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include "bit-array.h"
#include <math.h>

int Erastothenes(bit_array_t pole) {
  double max = sqrt(pole[0]); // odmocnina z poctu bitu = limit
  for(unsigned long i = 2; i < max; i++) {
  if(bit_array_getbit(pole,i) == 0) { // pokud je prvocislo..
    for(unsigned long j = 2; i*j < pole[0]; j++)
      bit_array_setbit(pole,i*j,1); // ..nastav 1 pro nasobky
    }
  }
  return 0;
}
