// steg-decode.c
// �e�en� IJC-DU1, p��klad 2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include "ppm.c"
#include "erastothenes.c"

#define RESOLUTION 3000000 // 3 * 1000 *1000 - max limit velikosti obrazku

int main(int argc, char *argv[]) {
  struct ppm *cyp;

  if(argc == 2)
    cyp = ppm_read(argv[1]);
  else {
    error_exit("Chybi argument filename.\n");
  }

  bit_array_create(field,RESOLUTION);
  Erastothenes(field);
  unsigned int secret = 0; // znak ukryte zpravy
  unsigned short c[CHAR_BIT] = {0}; // bit. pole pro vypocet znaku zpravy
  short counter = 0; // pocitadlo prubehu
  bool failsafe = 1; // objevil se znak '\0'

  for(unsigned long i = 11; i < RESOLUTION-1; i++) { // prvocisla od 11
    if(!bit_array_getbit(field,i)) { // je prvocislo
      if(counter == CHAR_BIT-1) { // pokud je posledni bit char
		c[CHAR_BIT-1-counter] = cyp->data[i-1] & 1; // pridani posledniho bitu do bit. pole
		while(counter >= 0) {
			secret += c[counter] * (int)pow(2,CHAR_BIT-1-counter); // vypocet hodnoty charu
			counter--;
		}
		if(secret == 0)
			failsafe = 0; // objevil se znak '\0'
		if(failsafe)
			printf("%c",secret); // tisk char tajne zpravy
    counter = 0; // nulovani
		secret = 0; // nulovani
		continue;
    }
      if(counter != CHAR_BIT-1 && counter < CHAR_BIT) {
        c[CHAR_BIT-1-counter] = cyp->data[i-1] & 1; // pridat bit do bit. pole
        counter++;
      }
    }

    if(!secret && !failsafe) { // ukonceni cyklu
      printf("\n");
      free(cyp);
      return 0;
    }
  }

	free(cyp);
	error_exit("Zprava nebyla ukoncena znakem '\0'.\n");
}
