// steg-decode.c
// �e�en� IJC-DU1, p��klad 1/2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include <stdlib.h>
#include <limits.h>
#include "error.h"

typedef unsigned long bit_array_t[];

#define bit_array_create(jmeno_pole, velikost) unsigned long jmeno_pole[1+velikost/(sizeof(unsigned long)*CHAR_BIT)+(velikost%(sizeof(unsigned long)*CHAR_BIT)!=0 ? 1:0)] = {velikost,0}
// bit_array_create pomoci makra. Objem pole: 1 (kvuli jmeno_pole[0]) + X unsigned long + zbytek co se neveslo do X (max. CHAR_BIT*UL-1) == max. 1UL

#ifdef USE_INLINE

inline unsigned long bit_array_size(bit_array_t jmeno_pole) {
    return jmeno_pole[0];
}

inline void bit_array_setbit(bit_array_t jmeno_pole, unsigned long index, unsigned int vyraz) { // nastavi hodnotu 1 || 0 vyraz do bitu na pozici index podle vzorce
   if(index > bit_array_size(jmeno_pole)) { // kontrola horni meze
    error_exit("%lu mimo rozsah 0..%lu\n", index, bit_array_size(jmeno_pole));
   }

    if(vyraz)
        jmeno_pole[1+index/(CHAR_BIT*sizeof(unsigned long))] |= (1UL << (index%(CHAR_BIT*sizeof(unsigned long))));
    else
        jmeno_pole[1+index/(CHAR_BIT*sizeof(unsigned long))] &= ~(1UL << (index%(CHAR_BIT*sizeof(unsigned long))));
}

inline int bit_array_getbit(bit_array_t jmeno_pole, unsigned long index) { // nacte hodnotu bitu na pozici index podle vzorce
  if(index > bit_array_size(jmeno_pole)) {
   error_exit("Index %lu mimo rozsah 0..%lu\n", index, bit_array_size(jmeno_pole));
  }
   return (jmeno_pole[1+index/(CHAR_BIT*sizeof(unsigned long))] >> (index%(CHAR_BIT*sizeof(unsigned long)))) & 1UL;
}

#else

#define bit_array_size(jmeno_pole) jmeno_pole[0]
#define bit_array_setbit(jmeno_pole, index, vyraz) \
do { \
	if(index > bit_array_size(jmeno_pole)) { \
     		error_exit("Index %lu mimo rozsah 0..%lu\n", index, bit_array_size(jmeno_pole)); \
    	} \
    	if(vyraz) \
        	jmeno_pole[1+ index/(CHAR_BIT*sizeof(unsigned long))] |= (1UL << (index%(CHAR_BIT*sizeof(unsigned long)))); \
    	else \
        	jmeno_pole[1+ index/(CHAR_BIT*sizeof(unsigned long))] &= ~(1UL << (index%(CHAR_BIT*sizeof(unsigned long)))); \
} while(0)

#define bit_array_getbit(jmeno_pole, index) \
    ((index > bit_array_size(jmeno_pole)) ? \
    (error_exit("%lu mimo rozsah 0..%lu\n", index, bit_array_size(jmeno_pole)),1) \
    : \
    (jmeno_pole[1+index/(CHAR_BIT*sizeof(unsigned long))] >> (index%(CHAR_BIT*sizeof(unsigned long)))) & 1UL) \

#endif
