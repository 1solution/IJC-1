// error.h
// �e�en� IJC-DU1, p��klad 1/2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

void warning_msg(const char *fmt, ...);
void error_exit(const char *fmt, ...);
