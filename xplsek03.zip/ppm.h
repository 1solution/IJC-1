// ppm.h
// �e�en� IJC-DU1, p��klad 2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

struct ppm {
       unsigned xsize;
       unsigned ysize;
       char data[]; // RGB * 3
};
struct ppm * ppm_read(const char * filename);
int ppm_write(struct ppm *p, const char * filename);
