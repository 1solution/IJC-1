// ppm.c
// �e�en� IJC-DU1, p��klad 2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include "ppm.h"
#include "error.c"

#define FAULT -1 // return chyba
#define DEPTH 255

struct ppm * ppm_read(const char * filename) {

  FILE *fp;
  fp = fopen(filename, "r");
  if(fp == NULL) {
    warning_msg("Soubor neexistuje nebo nejde otevrit.\n");
  fclose(fp);
  return NULL;
  }

  unsigned int x,y,depth;
  if((fscanf(fp, "P6 %u %u %u", &x, &y, &depth) != 3) || depth != DEPTH) { // kontrola formatu + jestli je hloubka opravdu 255
		warning_msg("Spatna hlavicka souboru.\n");
		fclose(fp);
		return NULL;
  }

  unsigned long bytes = 3*sizeof(char)*x*y; // celkova velikost datove casti ppm
  while(isspace(fgetc(fp))) ; // smaze mezery

  if(x > 0 && y > 0) {
    struct ppm *img = malloc(bytes+sizeof(struct ppm)); // alokace mista, struktura + pozadovana velikost
    if(img == NULL) {
		warning_msg("Malo pameti.\n");
		free(img);
		fclose(fp);
		return NULL;
      }
    img->xsize = x;
    img->ysize = y;

    unsigned long processed = fread(&img->data, sizeof(char), bytes, fp);
    if(processed != bytes-1) { // kontrola nacteni ppm dat. bez te -1 to nejelo, netusim proc. Je tam nejaky problem s mezerou ale neni cas
		warning_msg("Chyba v datove casti souboru.\n");
		free(img);
		fclose(fp);
		return NULL;
	}

    fclose(fp);
    return img;

  }
  else { // pokud je nevalidni rozmer x || y
    warning_msg("Chybny format souboru.\n");
    fclose(fp);
    return NULL;
  }
}

int ppm_write(struct ppm *p, const char * filename) {
  FILE *fc = fopen(filename,"w+");
  if(fc == NULL) {
    warning_msg("Soubor nelze vytvorit.\n");
  fclose(fc);
  return FAULT;
  }
  fprintf(fc, "P6\n%u %u\n255\n",p->xsize, p->ysize);
  unsigned long bytes = 3*sizeof(char)*p->xsize*p->ysize; // velikost datove casti ppm

  if(fwrite(p->data, sizeof(char), bytes, fc) != bytes) {
    warning_msg("Spatny format vkladanych dat.\n");
    fclose(fc);
    return FAULT;
  }

  fclose(fc);
  return 0;
}
