// error.c
// �e�en� IJC-DU1, p��klad 1/2, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include <stdarg.h>
#include "error.h"

void warning_msg(const char *fmt, ...) {
  va_list arg;
  va_start(arg, fmt);
  vfprintf(stderr,"CHYBA: ",arg);
  vfprintf(stderr,fmt,arg);
  va_end(arg);
}

void error_exit(const char *fmt, ...) {
  va_list arg;
  va_start(arg, fmt);
  vfprintf(stderr,"CHYBA: ",arg);
  vfprintf(stderr,fmt,arg);
  va_end(arg);
  exit(1);
}
