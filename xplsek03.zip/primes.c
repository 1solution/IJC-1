// primes.c
// �e�en� IJC-DU1, p��klad 1, 5.3.2018
// Autor: Michal Plsek, xplsek03, FIT
// P�elo�eno: gcc 6.4.0

#include <stdio.h>
#include "erastothenes.c"
#include "error.c"

#define LIMIT 222000000L // limit na prvocisla

int main() {
    bit_array_create(arr,LIMIT);
    unsigned long final[10]; // pole pro poslednich 10
    int count = 0;
    Erastothenes(arr);

	for(unsigned long i = LIMIT-1; i > 1; i--) {
	  if(count == 10)
	    break;
	  if(bit_array_getbit(arr,i) == 0) {
			final[9-count] = i;
			count++;
	  }
	}

	for(int i = 0; i < count; i++)
	  printf("%lu\n",final[i]);

    return 0;
}
